package com.example.workouttimerapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Timer timer = new Timer();
    TimerTask start;
    EditText workoutTypeText;
    TextView timeTimer;
    TextView lastWorkoutView;

    int seconds = 0;
    int minutes = 0;
    int hours = 0;
    String workout = "";
    String time = "00:00:00";
    String lastTime = "00:00:00";
    Boolean started = false;

    public void startTimer(View view)
    {
        if (!started)
        {
            started = true;
            start = new Start();
            timer.scheduleAtFixedRate(start, 0, 1000);
        }
    }

    public void pauseTimer(View view)
    {
        if (start != null) start.cancel();
        timer.purge();
        started = false;
    }

    public void stopTimer(View view)
    {
        workout = workoutTypeText.getText().toString();
        if (workout.equals(""))
        {
            workout = "your task";
        }
        if (start != null) start.cancel();
        timer.purge();
        seconds = 0;
        minutes = 0;
        hours = 0;
        lastTime = time;
        time = "00:00:00";
        timeTimer.setText(time);
        lastWorkoutView.setText("You spent " + lastTime + " on " + workout + " last time");
        started = false;
    }

    public class Start extends TimerTask
    {
        public void run()
        {
            String secondString;
            String minuteString;
            String hourString;
            seconds++;
            secondString = Integer.toString(seconds);

            if (seconds > 59) {
                seconds = 0;
                minutes++;
                secondString = "0";
                minuteString = Integer.toString(minutes);
            }
            else
            {
                secondString = Integer.toString(seconds);
            }

            if (minutes > 59) {
                minutes = 0;
                hours++;
                minuteString = "0";
                hourString = Integer.toString(hours);
            }
            else
            {
                hourString = Integer.toString(hours);
                minuteString = Integer.toString(minutes);
            }

            if (seconds < 10)
            {
                secondString = "0" + secondString;
            }
            if (minutes < 10)
            {
                minuteString = "0" + minuteString;
            }
            if (hours < 10)
            {
                hourString = "0" + hourString;
            }
            time = hourString + ":" + minuteString + ":" + secondString;
            timeTimer.setText(time);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putInt("Seconds", seconds);
        savedInstanceState.putInt("Minutes", minutes);
        savedInstanceState.putInt("Hours", hours);
        savedInstanceState.putString("Time", time);
        savedInstanceState.putString("LastTime", lastTime);
        savedInstanceState.putString("Workout", workout);
        savedInstanceState.putBoolean("Started", started);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lastWorkoutView = findViewById(R.id.lastWorkoutView);
        workoutTypeText = findViewById(R.id.workoutTypeText);
        timeTimer = findViewById(R.id.timeTimer);
        if (savedInstanceState != null)
        {
            Integer mySeconds = savedInstanceState.getInt("Seconds");
            Integer myMinutes = savedInstanceState.getInt("Minutes");
            Integer myHour = savedInstanceState.getInt("Hours");
            String myTime = savedInstanceState.getString("Time");
            String myLastTime = savedInstanceState.getString("LastTime");
            String myWorkout = savedInstanceState.getString("Workout");
            Boolean myStarted = savedInstanceState.getBoolean("Started");
            seconds = mySeconds;
            minutes = myMinutes;
            hours = myHour;
            time = myTime;
            lastTime = myLastTime;
            workout = myWorkout;
            started = myStarted;
            timeTimer.setText(time);
            if (workout != "") lastWorkoutView.setText("You spent " + lastTime + " on " + workout + " last time");
            if (started)
            {
                start = new Start();
                timer.scheduleAtFixedRate(start, 0, 1000);
            }
        }
    }
}